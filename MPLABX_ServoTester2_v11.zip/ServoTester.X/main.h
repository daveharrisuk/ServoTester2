/**@headerfile main.h        PROJECT_NAME "ServoTester2"
*****************************************************************************

@author �2023 Dave Harris, Andover, UK.  (MERG member 'WortingUK')
@copyright Creative Commons BY-NC-SA (Attribution-NonCommercial-ShareAlike)

@version 0.1
@history 23-Nov-2022 DH started
@history 26-Jan-2023 DH Stable version
@history 07-May-2023 DH updated - define of sense resistor calcs
*/

#pragma once /* header include guard */

/****************************************************************************
@brief include/libraries
*/

#include "mcc_generated_files/mcc.h" /* MPLABX Code Configurator generated */


/****************************************************************************
@brief Project Configuration
    RevA module is different from RevB module
*/

#ifdef REVA
    #define R5_OHM 0.5 /* RevA module has R5 (Rsense) as */
    #define VDD_LOW 4.70 /* Vdd low Volt threshold */
    #define GRN_mA 20  /* mA threshold for green LED */
    #define RED_mA 250 /* mA threshold for red LED */
#endif

#ifdef REVB
    #define R5_OHM 0.2 /* RevB module has R5 as */
    #define VDD_LOW 4.70 /* Vdd low Volt threshold */
    #define GRN_mA 25  /* mA threshold for green LED */
    #define RED_mA 250 /* mA threshold for red LED */
#endif

#ifndef R5_OHM
 #error MPLABX Config is NOT REVA | REVB. Production>Set Project Configuration
#endif


#define DC_MIDPOS10us   150 /* 1.5ms mid travel at 10us intervals */

#define PWM_PERIOD10us 2000 /* 20ms in 10us steps */


/****************************************************************************
@brief Data types
*/

typedef uint8_t count_dc_10us_t; /* 0 to 255 in 10 us steps = 0 to 2.55 ms */

typedef uint8_t count_20ms_t; /* 0 to 255 in 20 ms steps = 0 to 12.25 sec */

/* typedef uint16_t adc_result_t is from adc.h   0 to 1023 counts */


/****************************************************************************
@brief enum and constants
*/

    /* VDD measure = ADC of FVR chan & ADPREF is variable VDD is inverse */
    /*  = (1024 x 1.024) / VDD = 1048.576 / 4.9 = 213.99                 */
const uint16_t VDD_THRESHOLD = (uint16_t) ((1048.58 * 100) / (VDD_LOW * 100));


/* ADC result mV (0-1023) = Iservo(mA) x R5_OHM */

const uint16_t GRN_THRESHOLD = (uint16_t) (GRN_mA * R5_OHM);

const uint16_t RED_THRESHOLD = (uint16_t) (RED_mA * R5_OHM);


enum blink_t {BLINK_OFF, BLINK_ON}; /* for faults */

enum phase_t {PHASE_MINUS, PHASE_PLUS, PHASE_CENTER};

enum sw1_t {SW1_RUN = 1, SW1_HOLD = 0};

enum adPref_t {ADPREF_VDD, ADPREF_FVR};

enum seconds_t
{
    SECONDS20ms_1 = 1000 / 20, /* 1000 ms / 20 ms = 50  */
    SECONDS20ms_2 = 2000 / 20, /* 2000 ms / 20 ms = 100 */
};


/****************************************************************************
@brief function prototypes
*/

void main(void); /* Power up code */

void tmr0_ISR_PWM(void); /* PWM generator, on TMR0 overflow every 10us */

void processServo(enum phase_t, enum seconds_t);

count_dc_10us_t readPotDCcount(void); /* Read the pot value (0 to 100) */

adc_result_t readServoAmps(void); /* Read the current sense resistor */

void testForVDDfault(void); /* Fault indicate if VDD is low */

void setAdcPosRefVolt(enum adPref_t); /* set ADC plus ref - PIC16F1xxxx only */

void displayCurrentOnLEDs(adc_result_t); /* decode mA to LED states */

void yellowBlink(enum blink_t); /* blink or flash yellow LED  */


/****************************************************************************
@brief Global variables
   communication between foreground tmr0 ISR code and background code
*/

/* 150x10us = 1.50 ms mid travel pulse - limits: 50 = 0.5 ms to 250 = 2.5 ms */
volatile count_dc_10us_t g_pwmDCcount = DC_MIDPOS10us; /* set PWM duty cycle */ 

volatile count_20ms_t g_countIsr20ms = 0; /* 0 to 255. 255 x 20ms = 5.1s */

volatile uint8_t g_pwmDoneFlag; /* PWM pulse complete flag. */


/**************************** End of File **********************************/
