/**@headerfile main.h        PROJECT_NAME "ServoTester2"

@author (c)2022 Dave Harris, Andover, UK.  (MERG member 'WortingUK')
@copyright  Creative Commons BY-NC-SA (Attribution-NonCommercial-ShareAlike)

@version 0.1
@history 23-Nov-2022 v0.1 DH started
*/

#pragma once /* include guard */

/****************************************************************************
@brief include/libraries
*/

#include "mcc_generated_files/mcc.h" /* MPLAB Code Configurator generated */

/****************************************************************************
@brief  Data types and constants
*/

enum phase_t { PHASEPLUS = 1, PHASEMINUS = -1 };

enum adRef_t { ADREF5v, ADREF1v };

typedef uint16_t DC_count_t;

typedef uint16_t time_ms_t;

enum /* collection of servo PWM DC (duty cycle) count constants */
{
    DC_0_50ms = 16, /* 0.50 ms wide (180 degree) low end travel */
    DC_1_00ms = 32, /* 1.00 ms normal (90 degree) low end travel */
    DC_1_50ms = 47, /* 1.50 ms mid position travel */
    DC_2_00ms = 63, /* 2.00 ms normal (90 degree) high end travel */
    DC_2_50ms = 79, /* 2.50 ms wide (180 degree) high end travel */
};

enum mA_threshold_t /* Volt/mA is 0.00025v on 0.25ohm */ /* ADC ref 1.024v */
{
    mA_10 = 3,
    mA_50 = 13,
    mA_100 = 25,
    mA_500 = 125,
    mA_1000 = 250,
    mA_1200 = 300,
    mA_2000 = 500,
};

/****************************************************************************
@brief function prototypes
*/

void main(void); /* Power up code */

void processServo(DC_count_t targetDC, time_ms_t duration_ms);

DC_count_t getPotDutyCycleCount(void); /* Read the pot value */

adc_result_t readSenseAmps(void); /* Read the amp sense resistor */

void avg_ExponentialWeightedMoving(uint16_t value, uint16_t * avg); /* EWMA */

void setAD_RefVolts(enum adRef_t adRef); /* adc.h API does not have this */

void decodeAmpsToLED(void);

/****************************************************************************
@brief Global variables
*/

adc_result_t mAshunt; /* the servo mA */

/**************************** End of File **********************************/
