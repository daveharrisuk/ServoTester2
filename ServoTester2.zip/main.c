/**@file main.c        @PROJECT_NAME "ServoTester2"
*****************************************************************************
@brief  Exercise servo movement while monitoring current demand from servo.
   Servo movement sweeps either side of mid position, the range of sweep 
   controlled by turning potentiometer, from zero sweep through to max sweep.
   Pot configuration allows normal sweep (1ms/2ms) or wide sweep (0.5ms/2.5ms).
   Current monitor shows on 2 LEDS, indicating up to 3 current ranges.
 
@author (c)2022 Dave Harris, Andover, UK.  (MERG member 2740 'WortingUK')
@copyright Creative Commons BY-NC-SA (Attribution-NonCommercial-ShareAlike)
 
@version 0.1

@history 23-Nov-2022 v0.1 DH started
 
@brief  Environment
   Language  C99
   IDE       Microchip MPLAB X v5.50, using MCC (MPLAB Code Configurator) v4.
   Compiler  XC8 v2.32 (free). Device Family Pack: PIC16F1xxxx_DFP (v1.13.178)
   MCU       Microchip PIC16F18313 (HFINTOSC 2MHz, )
   PCB       TODO. For now on breadboard.

@brief MCU Peripheral configuration (Setup in MCC(defined in MCC)
   TMR2 - PreScaler 1:64, Period 19.968ms, used by PWM
   PWM5 - 9 bit resolution (due to limitations of TMR2)
   FVR  - Fixed Voltage Reference and ADFVR gain x1 = 1.024v into VPREF
   ADC  - 10 bit, FOSC/2 (TAD 1.0us), Conversion 11.5us, right align.
            Selectable VPREF = VDD (for pot reading) or FVR (Amp sense reading)

@brief MCU pin configuration
  Pins names configured in MCC and defined in pin_manager.h
                          PIN_LED1, PIN_LED2, PIN_AN_POT, PIN_AN_SENSE, PIN_SW1
    PIC 16F1xxxx top view        +---_---+   SOIC package
                        VDD 5.0V | 1   8 | VSS 0V
            LED1 red - 2k2 < RA5 | 2   7 | RA0/ICSPDAT - AN0 < Pot sweep
      Amps 0R5 sense > AN4 - RA4 | 3   6 | RA1/ICSPCLK - RA1 > 2k2 - LED1 yellow
    HoldSW > ^RA3 - RA3/MCLR/VPP | 4   5 | RA2 - PWM5 > Servo
                                 +-------+                       ^ is WPU
    The ICSP header is also the operational potentiometer/switch connections.

@brief Memory usage summary
    Program space        used   18Eh (   398) of   800h words   ( 19.4%)
    Data space           used    1Ch (    28) of   100h bytes   ( 10.9%)
*/
/****************************************************************************
@brief include/libraries
*/

#include "main.h" /* main header - data type, constant, global variable */

/****************************************************************************
@brief function average() - Simple average.

@param[in]  uint16_t value
@param[in,out] uint16_t *avg
@return none
*/

void average( uint16_t value, uint16_t *avg )
{
    *avg = (*avg + value) / 2;
}

/****************************************************************************
@brief function getPotDutyCycleCount() - get and condition the pot value

@param  none
@return DC_count_t - duty cycle count
*/

DC_count_t getPotDutyCycleCount(void)
{
    setAD_RefVolts( ADREF5v );
    return ADC_GetConversion( PIN_AN_POT ) / 32;
}

/****************************************************************************
@brief function readSenseAmps() - get and condition the sense Amps value

@param  none
@return adc_result_t - amps 
*/

adc_result_t readSenseAmps(void)
{
    setAD_RefVolts( ADREF1v );
    return ADC_GetConversion( PIN_AN_SENSE );
}

/****************************************************************************
@brief function setAD_RefVolts() - MCC adc.h API does not have this function

@remark This is specific to PIC16F1xxxx with FVR
@param[in] enum adRef_t adRef - ADREF1v is FVR 1.024v, adRef = ADREF5v is VDD 5v
@return none
*/

void setAD_RefVolts( enum adRef_t adRef )
{
    switch(adRef)
    { 
        case ADREF1v :
            ADCON1bits.ADPREF = 0b11; /* ADC Vref+ is FVR at 1.024v */
            break;
        case ADREF5v :
            ADCON1bits.ADPREF = 0b00; /* ADC Vref+ is VDD 5v */
            break;
    }
}

/***************************************************************************
@brief function decodeAmpsToLED()

@remark reads global vars  mAshunt 
@param  none
@return void
*/

void decodeAmpsToLED(void)
{
    if( mAshunt > mA_1200)
    {
        PIN_LED1_SetHigh();
        PIN_LED2_SetHigh();
    }
    else if( mAshunt > mA_50 )
    {
        PIN_LED1_SetLow();
        PIN_LED2_SetHigh();
    }
    else
    {
        PIN_LED1_SetLow();
        PIN_LED2_SetLow();
    }
}

/***************************************************************************
@brief function processServo() - process servo duty cycle movement

@remark uses global var mAshunt
@param[in] DC_count_t targetDC - dutyCycle count
@param[in] time_ms_t duration_ms - duration in milli seconds
@return none
*/

void processServo( DC_count_t targetDC, time_ms_t duration_ms )
{
    PWM5_LoadDutyValue(targetDC);
    for( time_ms_t ms = 0 ; ms < duration_ms; ms++)
    {
        __delay_ms( 1 );
        average( readSenseAmps(), &mAshunt );
        decodeAmpsToLED();
    }
}

/****************************************************************************
@brief function main() - Called on power up

@param  none
@return none
*/

void main(void)
{
    static int8_t phase = PHASEPLUS;
    
    SYSTEM_Initialize(); /* defined in MCC */

    processServo( DC_1_50ms, 1000 ); /* initial servo position */
    
    while(true) /* loop forever */
    {
        if( PIN_SW1_GetValue() == 1 ) /* in Run mode ? */
        {
            phase = ! phase;  /* invert phase in Run mode */
        }
        
        if( phase == PHASEPLUS )
        {
            processServo( ( DC_1_50ms + getPotDutyCycleCount() ), 250 ) ; 
            processServo( ( DC_1_50ms + getPotDutyCycleCount() ), 250 ) ; 
        }
        else /* PhaseMinus */
        { 
            processServo( ( DC_1_50ms - getPotDutyCycleCount() ), 250 );
            processServo( ( DC_1_50ms - getPotDutyCycleCount() ), 250 );
        }
    }
}

/**************************** End of File ***********************************/
